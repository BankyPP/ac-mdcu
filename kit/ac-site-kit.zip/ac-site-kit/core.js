const IMGS={};
const QB=[];
