# AC Site Kit — คลังข้อสอบเก่า (สำเนาเว็บ "AC Gen Sx Y4" แบบเปล่า)

โค้ดชุดเดียวกับเว็บต้นฉบับทุกบรรทัด: หน้าเลือกวอร์ด → home (MCQ/MEQ/OSCE · Phase 1/2 · 9 round) → หน้าทำโจทย์แบบกระดาษคำตอบ OMR
ยังไม่มีข้อสอบ — ใส่วอร์ดไหนก็ได้ (ดู PROMPT.md สำหรับสั่ง Claude, FEATURES.md สำหรับรายการฟีเจอร์ทั้งหมด)

```
template.html          หน้าตาหน้าโจทย์/กระดาษคำตอบ (CSS ต้นฉบับ) — build_site.py ดึง <head> + CSS จากไฟล์นี้
site/body.html         โครงหน้า (แถบบน, main, แถบล่าง, แผงกระดาษคำตอบ)
site/extra.css         CSS ส่วนเว็บ (home, round, โน้ต, ปุ่มต่าง ๆ)
site/app.js            ตัวแอปทั้งหมด (หน้า, round, phase, โน้ต/ลายมือ, ถาม Claude, sync, ย้ายความคืบหน้า)
config.json            ชื่อ/หัวข้อ/ปี/storageKey/วอร์ด — ไฟล์เดียวที่ต้องแก้ตอนตั้งค่า
core.js                const IMGS={}; const QB=[];  (ใช้กับ tools/)
data/data_bN.js        ข้อสอบวอร์ดแรก 1 ไฟล์ต่อ 1 ชุด (ปี + rotation) — N = ลำดับที่สร้าง → rid
<dir>/data_bN.js       วอร์ดอื่น: โฟลเดอร์ตาม config.json → wards[].dir
<dir>/highyield.js     (ไม่บังคับ) เนื้อหาหน้า High-yield / Keyword ของวอร์ดนั้น
img/*.jpg              รูปโจทย์ (q…) และรูปเฉลย/สไลด์ (k…) ทุกวอร์ด — ชื่อไฟล์ (ไม่รวมนามสกุล) = image key (ตั้ง prefix ต่างกันต่อวอร์ด)
build_site.py          python3 build_site.py [outdir]   → <outdir>/index.html + <outdir>/img/   (default docs/)
tools/validate.js      DIR=<dir> node tools/validate.js          → ต้องได้ "bad 0"
tools/optcheck.js      DIR=<dir> node tools/optcheck.js [fromRid] → ช้อยที่ใบ้คำตอบ (ช้อยถูกยาว/มีวงเล็บ)
tools/find.js          DIR=<dir> node tools/find.js "<regex>"     → ค้นข้อเดิมในคลังวอร์ดนั้น
tools/smoke_site.py    python3 tools/smoke_site.py [outdir]       → เปิดจริงใน Chromium ขนาดมือถือ ทุกวอร์ด/แท็บ + ตอบ 1 ข้อ, รายงาน error
examples/              ตัวอย่างไฟล์ข้อสอบ + highyield (อย่า build ตรง ๆ)
```

## Publish เป็น artifact ใน Claude
- `python3 build_site.py out` → publish `out/index.html`
- รูปทุกไฟล์ส่งเป็น supporting files `img/<ชื่อ>.jpg` (ห้ามฝัง base64 — หน้าจะเกิน 16 MB)
- capabilities: `db` + `user` (ซิงก์ความคืบหน้าเข้าบัญชี Claude ของคนที่เปิด: `data/users/<id>/meta`, `w_<วอร์ด>`, `ink_<hash>`) + `downloads` (ไฟล์สำรอง)
- ใน artifact "ส่งลิงก์ความคืบหน้า" จะให้เป็นรหัส `AC-PROGRESS:…` (artifact ไม่มีลิงก์ของตัวเอง) — ถ้าตั้ง `siteUrl` เป็นเว็บจริง จะได้เป็นลิงก์ไปเว็บนั้นแทน

## ถ้าจะย้ายไปเป็นเว็บของตัวเอง (GitHub Pages ฯลฯ)
- `python3 build_site.py docs` แล้วให้ GitHub Pages เสิร์ฟโฟลเดอร์ `/docs`
- ไม่มีบัญชี Claude ให้ซิงก์ → บันทึกในเบราว์เซอร์ + ลิงก์/ไฟล์สำรอง; ถ้าใส่ Firebase config ใน `config.json → firebase` จะมีปุ่มเข้าสู่ระบบ (Google / อีเมล / ชื่อผู้ใช้+รหัส) และซิงก์ข้ามเครื่อง
  - Firestore rules: `match /users/{uid}/{document=**} { allow read, write: if request.auth != null && request.auth.uid == uid; }`
  - Authentication → Authorized domains: เพิ่มโดเมนเว็บ

## ห้ามเปลี่ยนหลังเริ่มใช้งาน (ไม่งั้นความคืบหน้าหาย)
`storageKey`, `wards[].id`, และฟิลด์ที่ใช้สร้าง uid ของข้อ (set, ro, file, page, orig, 48 ตัวแรกของ stem)
