/* ตัวอย่างไฟล์ <โฟลเดอร์วอร์ด>/highyield.js — เนื้อหาหน้า "สรุป High-yield" และ "Keyword ตอบข้อสอบ" (Phase 2)
   Claude เขียนจากข้อสอบเก่าทุกข้อของวอร์ดนั้น (และ lecture ถ้ามี) — refs = rid ของข้อในคลัง (แอปแปลงเป็นเลขข้อที่แสดง และกดเปิดข้อนั้นได้)
   build_site.py จะห่อไฟล์นี้เป็น (function(W){ ... })(WARDS["<id>"]) — ให้กำหนด W.HY */
W.HY={
  topics:[
    {title:"Iron deficiency anemia", rep:3,
     points:["Ferritin ↓ ตัวแรก, TIBC ↑, %TS ↓ — ดูข้อ 12, 45","แยกจาก ACD: ferritin ↑/N, TIBC ↓/N"],
     refs:[1,12,45]},
    {title:"Febrile seizure", body:"simple vs complex — อายุ 6 เดือน–5 ปี …", refs:[7]}
  ],
  keywords:[
    {k:"microcytic + Mentzer &gt; 13", v:"IDA", refs:[1]},
    {k:"currant jelly stool", v:"intussusception", refs:[30]}
  ]
};
