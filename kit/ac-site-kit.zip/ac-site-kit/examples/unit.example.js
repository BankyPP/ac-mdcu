/* ตัวอย่างไฟล์ <โฟลเดอร์วอร์ด>/unit_<บท>.js — โจทย์ Unit round ของ lecture 1 บท (~200 ข้อ)
   build_site.py ห่อไฟล์นี้เป็น (function(W){W.UNIT=W.UNIT||[]; ... })(WARDS["<id>"])
   ทุกข้อ: case-based, โจทย์+ช้อยภาษาอังกฤษ formal, 5 ช้อย, เฉลยไทยครบหัวข้อ (รูปแบบเดียวกับข้อสอบเก่า แต่ไม่มี set/ro/file/page/orig/key)
   ห้ามเปลี่ยน id ของบท และห้ามสลับลำดับข้อเดิมหลังเริ่มใช้ (ความคืบหน้าผูกกับ id บท + ลำดับข้อ n) — เพิ่มข้อใหม่ต่อท้ายได้ */
W.UNIT.push({id:"hpb1", title:"Hepatobiliary I: Gallstone disease", short:"HPB I", src:"Lecture_Gallstone.pdf", QB:[
  {stem:"A 45-year-old woman presents with right upper quadrant pain for 2 days, fever of 38.5 °C and tenderness with inspiratory arrest on palpation of the right subcostal area. Which investigation should be performed first?",
   opts:["Ultrasound of the upper abdomen","CT of the abdomen","MRCP","HIDA scan","ERCP"], ans:0,
   interp:"…", why:"…", wrong:["…","…","…","…"], trap:"…",
   summary:["…","…","…"], guide:"Tokyo Guidelines 2018", mnemonic:"", variants:["…"]}
]});
